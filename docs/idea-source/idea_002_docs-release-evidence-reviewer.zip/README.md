# Docs・Release・検証証跡・素材レビュー 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | VSCodeExtension |
| No. | 2 |
| 分野 | 検証・公開証跡 |
| アイデア | Docs・Release・検証証跡・素材レビュー |
| リポジトリ名 | docs-release-evidence-reviewer |
| 概要 | Markdown、docs品質、Release、BOOTH、Pages公開前チェック、手動検証、画像、音声、図版プレビューをまとめる。 |
| 課題 | 公開前確認や手動検証の証跡が、ファイル、メモ、スクリーンショットに分散しやすい。 |
| 類似サービス・アプリ | Markdownlint, GitHub Pull Requests, Todo Tree, VS Code Preview |
| 差別化ポイント | 文書、素材、検証結果、公開前チェックを同じVS Codeビューにまとめる。 |

## 目的

このZIPには、`VSCodeExtension` 領域のアイデア `Docs・Release・検証証跡・素材レビュー` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
