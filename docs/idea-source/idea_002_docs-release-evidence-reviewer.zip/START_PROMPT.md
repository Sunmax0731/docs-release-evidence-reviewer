あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: VSCodeExtension
- No.: 2
- 分野: 検証・公開証跡
- アイデア: Docs・Release・検証証跡・素材レビュー
- リポジトリ名: docs-release-evidence-reviewer

## 元アイデア

- 概要: Markdown、docs品質、Release、BOOTH、Pages公開前チェック、手動検証、画像、音声、図版プレビューをまとめる。
- 課題: 公開前確認や手動検証の証跡が、ファイル、メモ、スクリーンショットに分散しやすい。
- 類似サービス・アプリ: Markdownlint, GitHub Pull Requests, Todo Tree, VS Code Preview
- 差別化ポイント: 文書、素材、検証結果、公開前チェックを同じVS Codeビューにまとめる。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
